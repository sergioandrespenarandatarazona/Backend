from django.apps import AppConfig


class LogicadnConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'principal'
